#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero;
    int sumaNumero=0;
    int promedioNumeros;
    int i=0;

    for(i;i<5;i++)//el int no lo ingreso en el for lo declaro afuera
    {
        printf("ingrese numero ");
        scanf("%d",&numero);
        sumaNumero= sumaNumero + numero;

    }
    promedioNumeros=sumaNumero/i;
    printf("El promedio de los numeros ingresados es : %d",promedioNumeros);
    return 0;
}
