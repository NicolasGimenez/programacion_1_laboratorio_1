#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED
typedef struct
{
    char nombreProducto[50];
    float precioProducto;
    int stockProducto;
    int idUsuario;
    int idProducto;//seria igual al idpublicacion
    int isEmpty;
    int cantidadVentas;
}Publicacion;
#endif // PUBLICACION_H_INCLUDED


int publicacion_init(Publicacion* array,int limite);
int publicacion_mostrar(Publicacion* array,int limite);
int publicacion_mostrarDebug(Publicacion* array,int limite);
int publicacion_alta(Publicacion* array,int limite,int idUsuario);
int publicacion_baja(Publicacion* array,int limite, int id);
int publicacion_modificacion(Publicacion* array,int limite, int id);
int publicacion_ordenar(Publicacion* array,int limite, int orden);
int buscarLugarLibre_publicacion(Publicacion* array,int limite);
int proximoId_publicacion();
