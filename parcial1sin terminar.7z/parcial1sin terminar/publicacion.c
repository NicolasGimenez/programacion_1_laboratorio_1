#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "utn.h"

/** \brief
 * \param array Publicacion*
 * \param limite int
 * \return int
 *
 */
int publicacion_init(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            array[i].isEmpty=1;
        }
    }
    return retorno;
}

int publicacion_mostrarDebug(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",array[i].idProducto, array[i].nombreProducto, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_mostrar(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",array[i].idProducto, array[i].nombreProducto, array[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_alta(Publicacion* array,int limite,int idUsuario)
{
    int retorno = -1;
    int i;
    char nombreProducto[50];
    float precio;
    int stock;
    if(limite > 0 && array != NULL)
    {
        i = buscarLugarLibre_publicacion(array,limite);
        if(i >= 0)
        {
            if(!getValidString("\nIngrese Nombre del producto ","\nEso no es un nombreProducto","El maximo es 40",nombreProducto,40,2))
            {
                if(!getValidFloat("Ingrese precio del producto","Error eso no es un precio valido",&precio,0,999999999,2))

               {
                   if(!getValidInt("Ingrese stock del producto","\n stock invalido\n",&stock,0,1000,2))
                   {
                        retorno = 0;
                        strcpy(array[i].nombreProducto,nombreProducto);
                        array[i].precioProducto= precio;
                        array[i].stockProducto= stock;
                        array[i].idProducto = proximoId_publicacion();
                        array[i].isEmpty = 0;
                        array[i].cantidadVentas = 0;
                   }
               }
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int publicacion_baja(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==id)
            {
                array[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}




int publicacion_modificacion(Publicacion* array,int limite, int id)
{
    int retorno = -1;
    int i;
    char nombreProducto[50];
    char password[50];
    if(limite > 0 && array != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && array[i].idProducto==id)
            {
                if(!getValidString("\nIngrese Nombre a modificar ","\nEso no es un nombreProducto","El maximo es 40",nombreProducto,40,2))
                {
                    printf("Ingrese password modificado");
                    fflush(stdin);
                    fgets(password,50,stdin);
                   if(!esAlfaNumerico(password))
                   {
                    retorno = 0;
                    strcpy(array[i].nombreProducto,nombreProducto);
                   }
                }
                else
                {
                    retorno = -3;
                }
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int publicacion_ordenar(Publicacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Publicacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].nombreProducto,array[i+1].nombreProducto) > 0 && orden) || (strcmp(array[i].nombreProducto,array[i+1].nombreProducto) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int buscarLugarLibre_publicacion(Publicacion* array,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(array[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


int proximoId_publicacion()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}
