#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "usuario.h"
#include "publicacion.h"
#include "utn.h"
#define SIZE 100
#define SIZE2 1000

int main()
{
    Usuario usuario[SIZE];
    Publicacion publicacion[SIZE2];
//    int i;
    int menu;
    int auxiliarId;
    int idUsuarioAuxiliar;

    usuario_init(usuario,SIZE);
    do
    {
        getValidInt("1.Alta de usuario\n2.Modificar datos de usuario\n3.Baja del usuario\n4.publicar producto\n5.Ordenar\n6.Mostrar Debug\n9.Salir\n","\nNo valida\n",&menu,1,9,1);
        switch(menu)
        {
            case 1:
                usuario_alta(usuario,SIZE);
                break;
            case 2:
                getValidInt("Ingrese el ID de la persona que quiera modificar","\nID ivalido\n",&auxiliarId,0,200,2);
                usuario_modificacion(usuario,SIZE,auxiliarId);

                break;
            case 3:
                getValidInt("Ingrese el ID de la persona que quiera borrar","\n ID ivalido\n",&auxiliarId,0,200,2);
                usuario_baja(usuario,SIZE,auxiliarId);
                break;
            case 4:
                getValidInt("Ingrese el ID del usuario","\nID ivalido\n",&idUsuarioAuxiliar,0,200,2);
                publicacion_alta(publicacion,SIZE2,idUsuarioAuxiliar);
                //usuario_mostrar(usuario,SIZE);
                break;
            case 5:
                getValidInt("Ingrese el ID del usuario","\nID ivalido\n",&idUsuarioAuxiliar,0,200,2);

                //usuario_ordenar(usuario,SIZE,0);
                break;
            case 6:
                usuario_mostrarDebug(usuario,SIZE);
                break;
        }

    }while(menu != 9);

    return 0;
}
