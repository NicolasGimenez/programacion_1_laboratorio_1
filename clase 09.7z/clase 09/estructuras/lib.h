#ifndef LIB_H_INCLUDED
#define LIB_H_INCLUDED
#define MAXCHAR 50
#define MAXIMO 2
#define MAXIMOPRODUCTOS 200
#define IDMAX 99999

typedef struct
{
    char nombre[MAXCHAR];
    char descripcion[MAXCHAR];
    float precio;
    int flagVacio;
    int id;

}EProducto;

int cargarDatosDeProducto( EProducto producto[],int indice);
void imprimirProductos(EProducto productos[],int indice);
int buscarLugar(EProducto array[],int cantidadElementos);



#endif // LIB_H_INCLUDED
