#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib.h"

int cargarDatosDeProducto(EProducto producto[],int indice)
{
    int id=0;
    printf("ingrese el nombre del producto\n");
    fflush(stdin);
    fgets(producto[indice].nombre,sizeof(producto[indice].nombre),stdin);


    printf("ingrese la descripcion del producto\n");
    fflush(stdin);
    fgets(producto[indice].descripcion,sizeof(producto[indice].descripcion),stdin);


    printf("ingrese el precio del producto\n");
    fflush(stdin);
    scanf("%f",&producto[indice].precio);

    producto[indice].id=id++;

    producto[indice].flagVacio=0;

    return 0;
}
void imprimirProductos(EProducto productos[],int indice)
{

    for(indice=0;indice<MAXIMO;indice++)
    {
     printf("%s\n%s\n%f\n",productos[indice].nombre,productos[indice].descripcion,productos[indice].precio);
    }
}

int buscarLugar(EProducto producto[],int cantidadElementos)
{

    int i;
    for (i=0; i<cantidadElementos; i++)
    {
        if (producto[i].flagVacio==-1)
        {
            return i;
        }
    }
    return -1;
}
