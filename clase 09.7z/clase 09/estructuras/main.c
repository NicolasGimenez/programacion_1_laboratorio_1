#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lib.h"
int codigoId(EProducto[]);
int main()
{
    EProducto producto[MAXIMOPRODUCTOS];
    int i,retorno;

    for (i=0; i<MAXIMOPRODUCTOS; i++)
    {
        producto[i].flagVacio=-1;
    }

    for(i=0; i<MAXIMO; i++)
    {
        cargarDatosDeProducto(producto,i);
        system("cls");
    }


    imprimirProductos(producto,MAXIMOPRODUCTOS);

    retorno=buscarLugar(producto,MAXIMOPRODUCTOS);

    if (retorno!=-1)
    {
        printf("se encontro un lugar en %d",retorno);
    }
    else if (retorno==-1)
    {
        printf("no hay lugar");
    }


    return 0;
}
